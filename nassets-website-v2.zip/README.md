# Nassets Technology Ltd. — Website concept

A responsive static website concept with the burgundy/gold/silver brand direction, local image assets, motion, product categories, and a favicon.

## Preview locally
Open `index.html` in a browser. No build step is required.

## Publish on GitHub Pages
1. Upload the contents of this folder to the root of your GitHub repository (so `index.html` is at repository root).
2. In repository Settings → Pages, choose the appropriate branch and `/ (root)`.
3. Wait for GitHub Pages to publish the site.

## Important before launch
- Product images are crops from a generated website art-direction mockup and are illustrative preview assets, not verified photographs of Nassets inventory. Replace them with licensed product photography or the company's own photos before public launch.
- The logo SVG is a clean concept reconstruction inspired by the provided brand board; replace it with the exact approved logo file if the company supplies one.
- Confirm company address, contact details, product availability and all claims.
- The enquiry interaction is preview-only; connect the official WhatsApp number or a real form before launch.
- Google Fonts requires an internet connection; system fallbacks are included.
